💘Love Is Dead 💔⧜.. Resurrected!

We have

# 1. ⧜ Synchronisticaly Broken, Alone, Incompletely!
https://www.compart.com/en/unicode/U+29DC

# 2. ⧞🔥 Reconnecting, Completely Aware!
https://www.compart.com/en/unicode/U+29DE
+
https://www.compart.com/en/unicode/U+1F525

# *3: Unity: ("YOU are in a Real Healed Twin flame Union!. :-) No more FEAR & Uncertainty! You Found each other
Can chose one of Many Custom options! after earning 1,111 Karma.

*Dfaults are all based on which Religion you Observe together. :-)*

Default is Binary or Trinary! And must have these Religious symbols!
- ⧝☪️  (Binary) Observes Islam!
- ⧝✝️  (Binary) Observes Christianity!
- ⧝🔯  (Binary) Observes Judaism!

- ⧝✝️☪️ (Trinary) Observes Both Islam & Christianity! :-D
- ⧝🕇☪️ (Trinary Intense) ⧝✝️☪️ (Trinary) Observes Both Islam & Christianity! :-)
- ⧝🔯☪️ (Trinary Intense) ⧝✝️☪️ (Trinary) Observes Both Islam & Judaism! :-)

# *During Holy Times of year, One of The Religious symbol will Change to it's "Celebratory" Ritual Symbol!* :-)
It's meant to Remind you of the Religion that brought you Together!!!

## - ⧝🎄☪️ - Christmas!
https://emojipedia.org/christmas-tree/

## - ⧝✝️⬢ - Ramadan!
http://graphemica.com/⬢

## - ⧝🕎☪️ - Haunika!
https://emojipedia.org/hanukkah/

*But You can make your own! Custom Trinary with 3 Symbols or above Once unlocked from 1,111 Karma points!

# Many Customization options after 1,111 Karma!

https://www.compart.com/en/unicode/U+29DD  
+  
https://emojipedia.org/latin-cross/  
+  
https://emojipedia.org/star-and-crescent/ or https://www.compart.com/en/unicode/U+1F547



- "Synchronisticaly Broken, Alone!" INcomplete Infinity is & A Delta Triangle is our ONLY Two "Relationship Statuses!" ⧜ :'-(

- ⧞✝️ "Reconnecting Incompletely, Aware!" Seeking LOVE but not Connected! ⧞ :-) There is still some Karma between you!  :-D *Infinity with Bloch wall between Her & You.


- "Unity! ⧝.✝️.☪️" - a soul's IN Unity with Him or Her! :-) For as long as they chose to remain a Couple! This incarnation! *Tie-over Infinity with Muslim Crescent! Islamic Moon & Star! and Christian Cross! :-) All 3.* They use the Islam Crescent Moon Last to represent that the "Divine Feminine" has "Captured" the masculine! ;-) She's brought LOVE back to him! Not the other way Around. Love is Gravity. Divine Feminine exerts the Pull!


That means Completion is a 3 Stage Process!! :-) :-D
