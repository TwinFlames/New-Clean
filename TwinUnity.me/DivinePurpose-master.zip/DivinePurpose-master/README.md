# Divine-Purpose
Plan! Logos, People, &amp; Decisions
